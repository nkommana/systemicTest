package com.systemic.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemicTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemicTestApplication.class, args);
	}
}
